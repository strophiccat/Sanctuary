﻿namespace Sanctuary.Packet;

public class ServerListRequest
{
    public const byte OpCode = 13;
}