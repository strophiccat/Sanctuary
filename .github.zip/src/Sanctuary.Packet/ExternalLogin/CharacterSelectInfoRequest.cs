﻿namespace Sanctuary.Packet;

public class CharacterSelectInfoRequest
{
    public const byte OpCode = 11;
}