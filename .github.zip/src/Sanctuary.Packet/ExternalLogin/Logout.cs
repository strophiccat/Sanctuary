﻿namespace Sanctuary.Packet;

public class Logout
{
    public const byte OpCode = 3;
}