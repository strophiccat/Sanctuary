﻿namespace Sanctuary.Packet;

public class PacketClientIsReady
{
    public const short OpCode = 13;
}