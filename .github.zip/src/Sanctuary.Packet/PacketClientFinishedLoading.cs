﻿namespace Sanctuary.Packet;

public class PacketClientFinishedLoading
{
    public const short OpCode = 10;
}