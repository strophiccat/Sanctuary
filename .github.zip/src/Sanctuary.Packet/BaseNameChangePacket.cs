﻿using Sanctuary.Core.IO;

namespace Sanctuary.Packet;

public class BaseNameChangePacket
{
    public const short OpCode = 192;

    private short SubOpCode;

    public BaseNameChangePacket(short subOpCode)
    {
        SubOpCode = subOpCode;
    }

    public void Write(PacketWriter writer)
    {
        writer.Write(OpCode);
        writer.Write(SubOpCode);
    }

    public bool TryRead(ref PacketReader reader)
    {
        if (!reader.TryRead(out short opCode) && opCode != OpCode)
            return false;

        if (!reader.TryRead(out short subOpCode) && subOpCode != SubOpCode)
            return false;

        return true;
    }
}