﻿namespace Sanctuary.Core.IO;

public interface ISerializablePacket
{
    byte[] Serialize();
}