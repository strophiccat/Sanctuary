﻿namespace Sanctuary.Core.Configuration;

public enum DatabaseProvider
{
    MySql,
    Sqlite
}