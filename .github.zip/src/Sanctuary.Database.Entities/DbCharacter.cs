﻿using System;
using System.Collections.Generic;

namespace Sanctuary.Database.Entities;

public class DbCharacter
{
    public ulong Id { get; set; }

    public Guid? Ticket { get; set; }

    public required string FirstName { get; set; }
    public string? LastName { get; set; }
    public string? FullName { get; set; }

    public int Model { get; set; }

    public required string Head { get; set; }
    public required int HeadId { get; set; }

    public required string Hair { get; set; }
    public required int HairId { get; set; }

    public string? ModelCustomization { get; set; }
    public int? ModelCustomizationId { get; set; }

    public string? FacePaint { get; set; }
    public int? FacePaintId { get; set; }

    public required string SkinTone { get; set; }
    public required int SkinToneId { get; set; }

    public int EyeColor { get; set; }
    public int HairColor { get; set; }

    public float? PositionX { get; set; }
    public float? PositionY { get; set; }
    public float? PositionZ { get; set; }
    public float? RotationX { get; set; }
    public float? RotationZ { get; set; }

    public int ActiveProfileId { get; set; }

    public int Gender { get; set; }

    public int? ActiveTitleId { get; set; }

    public float VipRank { get; set; }
    public int MembershipStatus { get; set; }

    public int ChatBubbleForegroundColor { get; set; } = 0x063C67;
    public int ChatBubbleBackgroundColor { get; set; } = 0xD4E2F0;
    public int ChatBubbleSize { get; set; } = 1;

    public int Coins { get; set; }
    public int StationCash { get; set; }

    public DateTimeOffset Created { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset? LastLogin { get; set; }

    public ICollection<DbItem> Items { get; set; } = new HashSet<DbItem>();
    public ICollection<DbTitle> Titles { get; set; } = new HashSet<DbTitle>();
    public ICollection<DbMount> Mounts { get; set; } = new HashSet<DbMount>();
    public ICollection<DbFriend> Friends { get; set; } = new HashSet<DbFriend>();
    public ICollection<DbIgnore> Ignores { get; set; } = new HashSet<DbIgnore>();
    public ICollection<DbProfile> Profiles { get; set; } = new HashSet<DbProfile>();

    public ulong UserId { get; set; }
    public DbUser User { get; set; } = null!;
}